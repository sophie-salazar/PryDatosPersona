package com.mycompany.prydatospersona;

import Vista.DatosPersonaVista;

public class PryDatosPersona {

    public static void main(String[] args) {
        DatosPersonaVista dpv=new DatosPersonaVista();
        dpv.setVisible(true);
    }
}
