/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pryradiobutton;

import View.OperacionesView;

public class PryRadioButton {

    public static void main(String[] args) {
        OperacionesView ov=new OperacionesView();
                ov.setVisible(true);
    }
}
